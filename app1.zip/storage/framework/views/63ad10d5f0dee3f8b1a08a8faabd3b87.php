<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php if (isset($component)) { $__componentOriginalb28564100b1201955612a134ea7ab6e6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb28564100b1201955612a134ea7ab6e6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.client-reviews','data' => ['reviews' => [
        [
            'name' => 'John Doe',
            'designation' => 'CEO, TechCorp',
            'avatar' => 'https://via.placeholder.com/150',
            'testimonial' => 'This company exceeded my expectations. Highly recommended!',
        ],
        [
            'name' => 'Jane Smith',
            'designation' => 'Marketing Manager, BizWorld',
            'avatar' => 'https://via.placeholder.com/150',
            'testimonial' => 'Exceptional service and outstanding support. Kudos to the team!',
        ],
        [
            'name' => 'Sam Wilson',
            'designation' => 'Freelancer',
            'avatar' => 'https://via.placeholder.com/150',
            'testimonial' => 'Great experience! I will definitely work with them again.',
        ],
    ]]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('client-reviews'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['reviews' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([
        [
            'name' => 'John Doe',
            'designation' => 'CEO, TechCorp',
            'avatar' => 'https://via.placeholder.com/150',
            'testimonial' => 'This company exceeded my expectations. Highly recommended!',
        ],
        [
            'name' => 'Jane Smith',
            'designation' => 'Marketing Manager, BizWorld',
            'avatar' => 'https://via.placeholder.com/150',
            'testimonial' => 'Exceptional service and outstanding support. Kudos to the team!',
        ],
        [
            'name' => 'Sam Wilson',
            'designation' => 'Freelancer',
            'avatar' => 'https://via.placeholder.com/150',
            'testimonial' => 'Great experience! I will definitely work with them again.',
        ],
    ])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb28564100b1201955612a134ea7ab6e6)): ?>
<?php $attributes = $__attributesOriginalb28564100b1201955612a134ea7ab6e6; ?>
<?php unset($__attributesOriginalb28564100b1201955612a134ea7ab6e6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb28564100b1201955612a134ea7ab6e6)): ?>
<?php $component = $__componentOriginalb28564100b1201955612a134ea7ab6e6; ?>
<?php unset($__componentOriginalb28564100b1201955612a134ea7ab6e6); ?>
<?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\app1\resources\views\pages\reviews.blade.php ENDPATH**/ ?>