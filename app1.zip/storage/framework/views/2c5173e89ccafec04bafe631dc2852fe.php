<div class=" w-full" data-aos="fade-up">
    <div class="flex flex-col w-full gap-y-5 p-5">
            <div class=" flex flex-col mx-auto items-center max-w-7xl   gap-y-5">
                <?php if (isset($component)) { $__componentOriginale42c205f32cbec3ded5d4ffcf1218796 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale42c205f32cbec3ded5d4ffcf1218796 = $attributes; } ?>
<?php $component = App\View\Components\H3::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('h3'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\H3::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'font-bold text-6xl']); ?>Technology and Innovation <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale42c205f32cbec3ded5d4ffcf1218796)): ?>
<?php $attributes = $__attributesOriginale42c205f32cbec3ded5d4ffcf1218796; ?>
<?php unset($__attributesOriginale42c205f32cbec3ded5d4ffcf1218796); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale42c205f32cbec3ded5d4ffcf1218796)): ?>
<?php $component = $__componentOriginale42c205f32cbec3ded5d4ffcf1218796; ?>
<?php unset($__componentOriginale42c205f32cbec3ded5d4ffcf1218796); ?>
<?php endif; ?>
                <img class="w-20" src="<?php echo e(asset('images/home/line_8.svg')); ?>" alt="erer">
                 <?php if (isset($component)) { $__componentOriginal9bea1a1944ba8334e0e356b0357f4b9d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9bea1a1944ba8334e0e356b0357f4b9d = $attributes; } ?>
<?php $component = App\View\Components\P::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('p'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\P::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'fony-thin text-center']); ?>Our company leverages advanced technologies, research, and innovative approaches to enhance operations, increase efficiency, and promote sustainability. <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9bea1a1944ba8334e0e356b0357f4b9d)): ?>
<?php $attributes = $__attributesOriginal9bea1a1944ba8334e0e356b0357f4b9d; ?>
<?php unset($__attributesOriginal9bea1a1944ba8334e0e356b0357f4b9d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9bea1a1944ba8334e0e356b0357f4b9d)): ?>
<?php $component = $__componentOriginal9bea1a1944ba8334e0e356b0357f4b9d; ?>
<?php unset($__componentOriginal9bea1a1944ba8334e0e356b0357f4b9d); ?>
<?php endif; ?>
            </div>
            <div>
                <div class="max-w-screen-2xl flex mx-auto justify-around items-center py-4 md:py-9 gap-x-5">
                    <?php if (isset($component)) { $__componentOriginale67687e3e4e61f963b25a6bcf3983629 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale67687e3e4e61f963b25a6bcf3983629 = $attributes; } ?>
<?php $component = App\View\Components\Button::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Button::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>Advanced drilling technology <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale67687e3e4e61f963b25a6bcf3983629)): ?>
<?php $attributes = $__attributesOriginale67687e3e4e61f963b25a6bcf3983629; ?>
<?php unset($__attributesOriginale67687e3e4e61f963b25a6bcf3983629); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale67687e3e4e61f963b25a6bcf3983629)): ?>
<?php $component = $__componentOriginale67687e3e4e61f963b25a6bcf3983629; ?>
<?php unset($__componentOriginale67687e3e4e61f963b25a6bcf3983629); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginale67687e3e4e61f963b25a6bcf3983629 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale67687e3e4e61f963b25a6bcf3983629 = $attributes; } ?>
<?php $component = App\View\Components\Button::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Button::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>Digital Transformation in Oil and Gas <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale67687e3e4e61f963b25a6bcf3983629)): ?>
<?php $attributes = $__attributesOriginale67687e3e4e61f963b25a6bcf3983629; ?>
<?php unset($__attributesOriginale67687e3e4e61f963b25a6bcf3983629); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale67687e3e4e61f963b25a6bcf3983629)): ?>
<?php $component = $__componentOriginale67687e3e4e61f963b25a6bcf3983629; ?>
<?php unset($__componentOriginale67687e3e4e61f963b25a6bcf3983629); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginale67687e3e4e61f963b25a6bcf3983629 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale67687e3e4e61f963b25a6bcf3983629 = $attributes; } ?>
<?php $component = App\View\Components\Button::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Button::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>Smart Refining and Processing <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale67687e3e4e61f963b25a6bcf3983629)): ?>
<?php $attributes = $__attributesOriginale67687e3e4e61f963b25a6bcf3983629; ?>
<?php unset($__attributesOriginale67687e3e4e61f963b25a6bcf3983629); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale67687e3e4e61f963b25a6bcf3983629)): ?>
<?php $component = $__componentOriginale67687e3e4e61f963b25a6bcf3983629; ?>
<?php unset($__componentOriginale67687e3e4e61f963b25a6bcf3983629); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginale67687e3e4e61f963b25a6bcf3983629 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale67687e3e4e61f963b25a6bcf3983629 = $attributes; } ?>
<?php $component = App\View\Components\Button::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Button::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>Renewable Energy and Low-Carbon Technologies <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale67687e3e4e61f963b25a6bcf3983629)): ?>
<?php $attributes = $__attributesOriginale67687e3e4e61f963b25a6bcf3983629; ?>
<?php unset($__attributesOriginale67687e3e4e61f963b25a6bcf3983629); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale67687e3e4e61f963b25a6bcf3983629)): ?>
<?php $component = $__componentOriginale67687e3e4e61f963b25a6bcf3983629; ?>
<?php unset($__componentOriginale67687e3e4e61f963b25a6bcf3983629); ?>
<?php endif; ?>
                </div>
                <div class="flex flex-col lg:flex-row max-w-7xl mx-auto">
                    <div class="lg:w-1/3 w-full">
                        <img  class="w-full h-full " src="<?php echo e(asset('images/home/tech1.svg')); ?>" alt="">
                    </div>
                    <div class="flex flex-col lg:w-2/3 w-full justify-center ">
                        <?php if (isset($component)) { $__componentOriginal9bea1a1944ba8334e0e356b0357f4b9d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9bea1a1944ba8334e0e356b0357f4b9d = $attributes; } ?>
<?php $component = App\View\Components\P::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('p'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\P::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'text-start font-bold px-2 py-3']); ?>Our exploration and production efforts are powered by advanced 3D seismic imaging and enhanced oil recovery techniques that allow us to extract resources efficiently while minimizing environmental disturbance. <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9bea1a1944ba8334e0e356b0357f4b9d)): ?>
<?php $attributes = $__attributesOriginal9bea1a1944ba8334e0e356b0357f4b9d; ?>
<?php unset($__attributesOriginal9bea1a1944ba8334e0e356b0357f4b9d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9bea1a1944ba8334e0e356b0357f4b9d)): ?>
<?php $component = $__componentOriginal9bea1a1944ba8334e0e356b0357f4b9d; ?>
<?php unset($__componentOriginal9bea1a1944ba8334e0e356b0357f4b9d); ?>
<?php endif; ?>
                        <ul class="py-8 px-2">
                            <li class="py-5 gap-x-3 flex items-center"> 
                                   <img  class=" " src="<?php echo e(asset('images/home/list_icon.svg')); ?>" alt="">    
                                3D Seismic Imaging: For precise identification of underground reserves.
                            </li>
                            <li class="py-5 gap-x-3 flex items-center"> 
                                   <img  class=" " src="<?php echo e(asset('images/home/list_icon.svg')); ?>" alt="">    
                                Directional Drilling: To access hard-to-reach reservoirs and maximize recovery.
                            </li>
                                                       <li class="py-5 gap-x-3 flex items-center"> 
                                   <img  class="" src="<?php echo e(asset('images/home/list_icon.svg')); ?>" alt="">    
                                Enhanced Oil Recovery (EOR): Techniques that increase the amount of crude oil extracted from existing fields.
                            </li>
                        </ul>
                        <a class="pl-8 underline text-button-blue gap-x-2 flex items-self-start" href="<?php echo e(url('/about')); ?>">Get Started <img src="<?php echo e(asset('images/home/direct_right.svg')); ?>" alt=""></a>
                    </div>
                </div>
                </div>

           

            </div>







         

    </div>
</div>


<?php /**PATH C:\xampp\htdocs\app1\resources\views\components\technology.blade.php ENDPATH**/ ?>