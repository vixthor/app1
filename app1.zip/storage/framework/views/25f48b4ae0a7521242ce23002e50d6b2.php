<div data-aos="fade-up"  class=" flex flex-col mx-auto items-center w-full max-w-7xl gap-y-1 lg:gap-y-">
                <?php if (isset($component)) { $__componentOriginale42c205f32cbec3ded5d4ffcf1218796 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale42c205f32cbec3ded5d4ffcf1218796 = $attributes; } ?>
<?php $component = App\View\Components\H3::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('h3'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\H3::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'font-bold text-6xl']); ?><?php echo e($slot); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale42c205f32cbec3ded5d4ffcf1218796)): ?>
<?php $attributes = $__attributesOriginale42c205f32cbec3ded5d4ffcf1218796; ?>
<?php unset($__attributesOriginale42c205f32cbec3ded5d4ffcf1218796); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale42c205f32cbec3ded5d4ffcf1218796)): ?>
<?php $component = $__componentOriginale42c205f32cbec3ded5d4ffcf1218796; ?>
<?php unset($__componentOriginale42c205f32cbec3ded5d4ffcf1218796); ?>
<?php endif; ?>
                <img class="w-20 md:-w-20" src="<?php echo e(asset('images/home/line_8.svg')); ?>" alt="erer">
</div><?php /**PATH C:\xampp\htdocs\app1\resources\views\components\yellowline.blade.php ENDPATH**/ ?>