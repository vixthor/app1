<div class="font-bold text-5xl">
    <?php echo e($slot); ?><!-- It is quality rather than quantity that matters. - Lucius Annaeus Seneca -->
</div><?php /**PATH C:\xampp\htdocs\app1\resources\views\components\h1.blade.php ENDPATH**/ ?>