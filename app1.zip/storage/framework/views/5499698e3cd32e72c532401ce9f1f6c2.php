<div>
     <div class=" w-full">
            <?php if (isset($component)) { $__componentOriginalf619838243246ac203927964a2f7f6b6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf619838243246ac203927964a2f7f6b6 = $attributes; } ?>
<?php $component = App\View\Components\Yellowline::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('yellowline'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Yellowline::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['data-aos' => 'fade-up']); ?>
                Who Are We
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf619838243246ac203927964a2f7f6b6)): ?>
<?php $attributes = $__attributesOriginalf619838243246ac203927964a2f7f6b6; ?>
<?php unset($__attributesOriginalf619838243246ac203927964a2f7f6b6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf619838243246ac203927964a2f7f6b6)): ?>
<?php $component = $__componentOriginalf619838243246ac203927964a2f7f6b6; ?>
<?php unset($__componentOriginalf619838243246ac203927964a2f7f6b6); ?>
<?php endif; ?>
            <div class=" ">
                <div class="slick-carousel2 overflow-x-hiddden py-20 mb-20">
                
                    <div class="flex flex-col justify-center gap-3 p-1 text-center items-center">
                        <img src="<?php echo e(asset('images/home/whoweare1.svg')); ?>" alt="Image 2">
                        <h3 class="pt-4 text-lg font-semibold text-center">Critical Thinkers</h3>
                    </div>
                    <div class="flex flex-col  p-1 gap-3 text-center items-center">
                        <img src="<?php echo e(asset('images/home/whoweare2.svg')); ?>" alt="Image 2">
                        <h3 class="pt-4 text-lg font-semibold text-center">Diverse People</h3>
                    </div>
                    <div class="flex flex-col p-1 gap-3 text-center items-center">
                        <img src="<?php echo e(asset('images/home/whoweare3.svg')); ?>" alt="Image 2">
                        <h3 class="pt-4 text-lg font-semibold text-center">Innovators</h3>
                    </div>
                                        <div class="flex flex-col p-1 gap-3 text-center items-center">
                        <img src="<?php echo e(asset('images/home/whoweare4.svg')); ?>" alt="Image 2">
                        <h3 class="pt-4 text-lg font-semibold text-center">Collaborators</h3>
                    </div>
                </div>
            </div>
             
        </div>  
    <!-- Because you are alive, everything is possible. - Thich Nhat Hanh -->
</div><?php /**PATH C:\xampp\htdocs\app1\resources\views\components\whoweare.blade.php ENDPATH**/ ?>