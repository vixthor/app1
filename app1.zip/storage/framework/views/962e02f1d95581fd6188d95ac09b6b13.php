<div <?php echo e($attributes->merge(['class' => 'text-center text-base'])); ?>>
   <?php echo e($slot); ?> <!-- Act only according to that maxim whereby you can, at the same time, will that it should become a universal law. - Immanuel Kant -->
</div><?php /**PATH C:\xampp\htdocs\app1\resources\views\components\p.blade.php ENDPATH**/ ?>