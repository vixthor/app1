<div data-aos="fade-up" class="w-full mt-20 dark:text-white dark:bg-gray-900">    <!-- I have not failed. I've just found 10,000 ways that won't work. - Thomas Edison -->
    <div class=" flex flex-col mx-auto items-center max-w-7xl gap-y-5">
                <?php if (isset($component)) { $__componentOriginale42c205f32cbec3ded5d4ffcf1218796 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale42c205f32cbec3ded5d4ffcf1218796 = $attributes; } ?>
<?php $component = App\View\Components\H3::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('h3'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\H3::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'font-bold text-6xl']); ?>Investor Relations <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale42c205f32cbec3ded5d4ffcf1218796)): ?>
<?php $attributes = $__attributesOriginale42c205f32cbec3ded5d4ffcf1218796; ?>
<?php unset($__attributesOriginale42c205f32cbec3ded5d4ffcf1218796); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale42c205f32cbec3ded5d4ffcf1218796)): ?>
<?php $component = $__componentOriginale42c205f32cbec3ded5d4ffcf1218796; ?>
<?php unset($__componentOriginale42c205f32cbec3ded5d4ffcf1218796); ?>
<?php endif; ?>
                <img src="<?php echo e(asset('images/home/line_8.svg')); ?>" alt="erer">
                 <?php if (isset($component)) { $__componentOriginal9bea1a1944ba8334e0e356b0357f4b9d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9bea1a1944ba8334e0e356b0357f4b9d = $attributes; } ?>
<?php $component = App\View\Components\P::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('p'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\P::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'fony-thin text-center']); ?>At Madu Alliance, we are at the forefront of Nigeria's energy industry, delivering world-class solutions across the entire oil and gas value chain. Our commitment to innovation, sustainability, and operational excellence drives our business, ensuring that we meet the energy needs of today while paving the way for a more sustainable tomorrow. <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9bea1a1944ba8334e0e356b0357f4b9d)): ?>
<?php $attributes = $__attributesOriginal9bea1a1944ba8334e0e356b0357f4b9d; ?>
<?php unset($__attributesOriginal9bea1a1944ba8334e0e356b0357f4b9d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9bea1a1944ba8334e0e356b0357f4b9d)): ?>
<?php $component = $__componentOriginal9bea1a1944ba8334e0e356b0357f4b9d; ?>
<?php unset($__componentOriginal9bea1a1944ba8334e0e356b0357f4b9d); ?>
<?php endif; ?>

        

    </div>
        <div class="overflow-x-hidden slick-carousel py-20 mb-20  text-white">
            <div class="p-2">
                <img class="relative w-full" src="<?php echo e(asset('images/home/report1.svg')); ?>" alt="Image 1">
                <div class="absolute px-4 py-6 bottom-3 left-0">
                    
                </div>
            </div>
             <div class="p-2">
                <img class="relative w-full" src="<?php echo e(asset('images/home/report2.svg')); ?>" alt="Image 1">
                <div class="absolute px-4 py-6 bottom-3 left-0">
                    
                </div>
            </div>
             <div class="p-2">
                <img class="relative w-full" src="<?php echo e(asset('images/home/report3.svg')); ?>" alt="Image 1">
                <div class="absolute px-4 py-6 bottom-3 left-0">
                    
                </div>
            </div>
             <div class="p-2">
                <img class="relative w-full" src="<?php echo e(asset('images/home/report4.svg')); ?>" alt="Image 1">
                <div class="absolute px-4 py-6 bottom-3 left-0">
                    
                </div>
            </div>
        </div>
</div><?php /**PATH C:\xampp\htdocs\app1\resources\views/components/relations.blade.php ENDPATH**/ ?>