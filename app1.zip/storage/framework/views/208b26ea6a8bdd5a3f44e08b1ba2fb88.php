<div class="w-full overflow-x-hidden mt-20 dark:text-white dark:bg-gray-900">
    <div class="w-full">
            <div class=" flex flex-col mx-auto items-center w-full gap-y-5 my-20">
                <?php if (isset($component)) { $__componentOriginale42c205f32cbec3ded5d4ffcf1218796 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale42c205f32cbec3ded5d4ffcf1218796 = $attributes; } ?>
<?php $component = App\View\Components\H3::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('h3'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\H3::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'font-bold text-6xl']); ?>Our Leaders <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale42c205f32cbec3ded5d4ffcf1218796)): ?>
<?php $attributes = $__attributesOriginale42c205f32cbec3ded5d4ffcf1218796; ?>
<?php unset($__attributesOriginale42c205f32cbec3ded5d4ffcf1218796); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale42c205f32cbec3ded5d4ffcf1218796)): ?>
<?php $component = $__componentOriginale42c205f32cbec3ded5d4ffcf1218796; ?>
<?php unset($__componentOriginale42c205f32cbec3ded5d4ffcf1218796); ?>
<?php endif; ?>
                <img class="w-22  " src="<?php echo e(asset('images/home/line_8.svg')); ?>" alt="erer">
                <?php if (isset($component)) { $__componentOriginal9bea1a1944ba8334e0e356b0357f4b9d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9bea1a1944ba8334e0e356b0357f4b9d = $attributes; } ?>
<?php $component = App\View\Components\P::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('p'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\P::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'fony-thin text-center']); ?>At Madu Alliance, our leadership team is composed of visionary individuals who bring decades of expertise, experience, and commitment to the energy industry. Together, they steer the company towards excellence in operational efficiency, sustainability, and innovation. Each leader is dedicated to delivering sustainable energy solutions while upholding the highest standards of corporate governance and responsibility. <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9bea1a1944ba8334e0e356b0357f4b9d)): ?>
<?php $attributes = $__attributesOriginal9bea1a1944ba8334e0e356b0357f4b9d; ?>
<?php unset($__attributesOriginal9bea1a1944ba8334e0e356b0357f4b9d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9bea1a1944ba8334e0e356b0357f4b9d)): ?>
<?php $component = $__componentOriginal9bea1a1944ba8334e0e356b0357f4b9d; ?>
<?php unset($__componentOriginal9bea1a1944ba8334e0e356b0357f4b9d); ?>
<?php endif; ?>
                <div class=" flex flex-col md:flex-row items-center">
                
                    
                    <div  data-aos="fade-down-left"  data-aos-duration="2000" class="w-full md:w-1/3 text-center p-7 flex flex-col gap-y-5">
                        <img class="w-full h-full" src="<?php echo e(asset('images/home/ourleaders.svg')); ?>" alt="Image 3">
                        <h3>[Full Name] – Chief Executive Officer (CEO)</h3>
                        <p class="text-center">As the CEO of [Company Name], [Full Name] brings over [X] years of experience in the oil and gas industry. Under [his/her] leadership, the company has achieved significant milestones in exploration, refining, and sustainability initiatives. [He/She] is dedicated to driving the company’s vision of becoming a leader in sustainable energy solutions across Nigeria and beyond.</p>
                    </div>
                    <div data-aos="fade-down"  data-aos-duration="2000" class="w-full  md:w-1/3 text-center p-7 flex flex-col gap-y-5">
                        <img class="w-full h-full" src="<?php echo e(asset('images/home/ourleaders.svg')); ?>" alt="Image 3">
                        <h3>[Full Name] – Chief Executive Officer (CEO)</h3>
                        <p class="text-center">As the CEO of [Company Name], [Full Name] brings over [X] years of experience in the oil and gas industry. Under [his/her] leadership, the company has achieved significant milestones in exploration, refining, and sustainability initiatives. [He/She] is dedicated to driving the company’s vision of becoming a leader in sustainable energy solutions across Nigeria and beyond.</p>
                    </div>
                    <div data-aos="fade-down-right"  data-aos-duration="2000" class="w-full  md:w-1/3 text-center p-7 flex flex-col gap-y-5">
                        <img class="w-full h-full" src="<?php echo e(asset('images/home/ourleaders.svg')); ?>" alt="Image 3">
                        <h3>[Full Name] – Chief Executive Officer (CEO)</h3>
                        <p class="text-center">As the CEO of [Company Name], [Full Name] brings over [X] years of experience in the oil and gas industry. Under [his/her] leadership, the company has achieved significant milestones in exploration, refining, and sustainability initiatives. [He/She] is dedicated to driving the company’s vision of becoming a leader in sustainable energy solutions across Nigeria and beyond.</p>
                    </div>
                </div>
            </div>
         
            
             
    </div>  
    <!-- Happiness is not something readymade. It comes from your own actions. - Dalai Lama -->
</div><?php /**PATH C:\xampp\htdocs\app1\resources\views\components\leaders.blade.php ENDPATH**/ ?>