<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
 




<button @click="toggleTheme()" class="px-4 py-2 m-2 bg-gray-300 dark:bg-gray-700 text-black dark:text-white rounded flex items-center">
    <svg x-show="!darkMode" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" class="h-5 w-5 mr-2">
        <path stroke-linecap="round" stroke-linejoin="round" d="M12 3v2m0 14v2m9-9h-2m-14 0H3m16.364-7.364l-1.414 1.414M7.05 16.95l-1.414 1.414m12.728 0l1.414-1.414M7.05 7.05l1.414-1.414" />
    </svg>
    <svg x-show="darkMode" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" class="h-5 w-5 mr-2">
        <path stroke-linecap="round" stroke-linejoin="round" d="M12 3v2m0 14v2m9-9h-2m-14 0H3m16.364-7.364l-1.414 1.414M7.05 16.95l-1.414 1.414m12.728 0l1.414-1.414M7.05 7.05l1.414-1.414" />
    </svg>
    
</button>
   
    <?php if (isset($component)) { $__componentOriginal2a2e454b2e62574a80c8110e5f128b60 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2a2e454b2e62574a80c8110e5f128b60 = $attributes; } ?>
<?php $component = App\View\Components\Header::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Header::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2a2e454b2e62574a80c8110e5f128b60)): ?>
<?php $attributes = $__attributesOriginal2a2e454b2e62574a80c8110e5f128b60; ?>
<?php unset($__attributesOriginal2a2e454b2e62574a80c8110e5f128b60); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2a2e454b2e62574a80c8110e5f128b60)): ?>
<?php $component = $__componentOriginal2a2e454b2e62574a80c8110e5f128b60; ?>
<?php unset($__componentOriginal2a2e454b2e62574a80c8110e5f128b60); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal89d9bfd62024608d2b27491dcd181984 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal89d9bfd62024608d2b27491dcd181984 = $attributes; } ?>
<?php $component = App\View\Components\Whatwedo::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('whatwedo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Whatwedo::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal89d9bfd62024608d2b27491dcd181984)): ?>
<?php $attributes = $__attributesOriginal89d9bfd62024608d2b27491dcd181984; ?>
<?php unset($__attributesOriginal89d9bfd62024608d2b27491dcd181984); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal89d9bfd62024608d2b27491dcd181984)): ?>
<?php $component = $__componentOriginal89d9bfd62024608d2b27491dcd181984; ?>
<?php unset($__componentOriginal89d9bfd62024608d2b27491dcd181984); ?>
<?php endif; ?>
    <!-- good --> <?php if (isset($component)) { $__componentOriginal032e7386f8a2e0004922e8ad617d6952 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal032e7386f8a2e0004922e8ad617d6952 = $attributes; } ?>
<?php $component = App\View\Components\Backdrop::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backdrop'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Backdrop::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal032e7386f8a2e0004922e8ad617d6952)): ?>
<?php $attributes = $__attributesOriginal032e7386f8a2e0004922e8ad617d6952; ?>
<?php unset($__attributesOriginal032e7386f8a2e0004922e8ad617d6952); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal032e7386f8a2e0004922e8ad617d6952)): ?>
<?php $component = $__componentOriginal032e7386f8a2e0004922e8ad617d6952; ?>
<?php unset($__componentOriginal032e7386f8a2e0004922e8ad617d6952); ?>
<?php endif; ?>
    <!-- good --> <?php if (isset($component)) { $__componentOriginal28cc6b2cbc31d03ccc49d313c16a5874 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal28cc6b2cbc31d03ccc49d313c16a5874 = $attributes; } ?>
<?php $component = App\View\Components\Whatweoffer::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('whatweoffer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Whatweoffer::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal28cc6b2cbc31d03ccc49d313c16a5874)): ?>
<?php $attributes = $__attributesOriginal28cc6b2cbc31d03ccc49d313c16a5874; ?>
<?php unset($__attributesOriginal28cc6b2cbc31d03ccc49d313c16a5874); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal28cc6b2cbc31d03ccc49d313c16a5874)): ?>
<?php $component = $__componentOriginal28cc6b2cbc31d03ccc49d313c16a5874; ?>
<?php unset($__componentOriginal28cc6b2cbc31d03ccc49d313c16a5874); ?>
<?php endif; ?>
    <!-- good --> <?php if (isset($component)) { $__componentOriginal3109e6ecef214068b360752cf96fbd20 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3109e6ecef214068b360752cf96fbd20 = $attributes; } ?>
<?php $component = App\View\Components\Whoweare::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('whoweare'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Whoweare::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3109e6ecef214068b360752cf96fbd20)): ?>
<?php $attributes = $__attributesOriginal3109e6ecef214068b360752cf96fbd20; ?>
<?php unset($__attributesOriginal3109e6ecef214068b360752cf96fbd20); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3109e6ecef214068b360752cf96fbd20)): ?>
<?php $component = $__componentOriginal3109e6ecef214068b360752cf96fbd20; ?>
<?php unset($__componentOriginal3109e6ecef214068b360752cf96fbd20); ?>
<?php endif; ?>
    <!-- good --> <?php if (isset($component)) { $__componentOriginal7106e1aa7ff2a961a54db870e9066963 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7106e1aa7ff2a961a54db870e9066963 = $attributes; } ?>
<?php $component = App\View\Components\Technology::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('technology'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Technology::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7106e1aa7ff2a961a54db870e9066963)): ?>
<?php $attributes = $__attributesOriginal7106e1aa7ff2a961a54db870e9066963; ?>
<?php unset($__attributesOriginal7106e1aa7ff2a961a54db870e9066963); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7106e1aa7ff2a961a54db870e9066963)): ?>
<?php $component = $__componentOriginal7106e1aa7ff2a961a54db870e9066963; ?>
<?php unset($__componentOriginal7106e1aa7ff2a961a54db870e9066963); ?>
<?php endif; ?>
    <!-- good --> <?php if (isset($component)) { $__componentOriginal6c0e035ecd1ed3ca7c178bf3f281d717 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6c0e035ecd1ed3ca7c178bf3f281d717 = $attributes; } ?>
<?php $component = App\View\Components\Environment::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('environment'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Environment::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6c0e035ecd1ed3ca7c178bf3f281d717)): ?>
<?php $attributes = $__attributesOriginal6c0e035ecd1ed3ca7c178bf3f281d717; ?>
<?php unset($__attributesOriginal6c0e035ecd1ed3ca7c178bf3f281d717); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6c0e035ecd1ed3ca7c178bf3f281d717)): ?>
<?php $component = $__componentOriginal6c0e035ecd1ed3ca7c178bf3f281d717; ?>
<?php unset($__componentOriginal6c0e035ecd1ed3ca7c178bf3f281d717); ?>
<?php endif; ?>
    <!-- good --> <?php if (isset($component)) { $__componentOriginala431f2ce7de38c890544e53a9d74faa2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala431f2ce7de38c890544e53a9d74faa2 = $attributes; } ?>
<?php $component = App\View\Components\Social::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('social'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Social::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala431f2ce7de38c890544e53a9d74faa2)): ?>
<?php $attributes = $__attributesOriginala431f2ce7de38c890544e53a9d74faa2; ?>
<?php unset($__attributesOriginala431f2ce7de38c890544e53a9d74faa2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala431f2ce7de38c890544e53a9d74faa2)): ?>
<?php $component = $__componentOriginala431f2ce7de38c890544e53a9d74faa2; ?>
<?php unset($__componentOriginala431f2ce7de38c890544e53a9d74faa2); ?>
<?php endif; ?>
    <!-- good --> <?php if (isset($component)) { $__componentOriginal4408a4cb4e430410b715cedcfd557bd5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4408a4cb4e430410b715cedcfd557bd5 = $attributes; } ?>
<?php $component = App\View\Components\Leaders::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('leaders'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Leaders::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4408a4cb4e430410b715cedcfd557bd5)): ?>
<?php $attributes = $__attributesOriginal4408a4cb4e430410b715cedcfd557bd5; ?>
<?php unset($__attributesOriginal4408a4cb4e430410b715cedcfd557bd5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4408a4cb4e430410b715cedcfd557bd5)): ?>
<?php $component = $__componentOriginal4408a4cb4e430410b715cedcfd557bd5; ?>
<?php unset($__componentOriginal4408a4cb4e430410b715cedcfd557bd5); ?>
<?php endif; ?>
    <!-- good --> <?php if (isset($component)) { $__componentOriginal536faf66b388aedc26f3b15a0f64c2a9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal536faf66b388aedc26f3b15a0f64c2a9 = $attributes; } ?>
<?php $component = App\View\Components\Relations::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('relations'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Relations::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal536faf66b388aedc26f3b15a0f64c2a9)): ?>
<?php $attributes = $__attributesOriginal536faf66b388aedc26f3b15a0f64c2a9; ?>
<?php unset($__attributesOriginal536faf66b388aedc26f3b15a0f64c2a9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal536faf66b388aedc26f3b15a0f64c2a9)): ?>
<?php $component = $__componentOriginal536faf66b388aedc26f3b15a0f64c2a9; ?>
<?php unset($__componentOriginal536faf66b388aedc26f3b15a0f64c2a9); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal3d452745d4a5eb38b6bef38907945e76 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3d452745d4a5eb38b6bef38907945e76 = $attributes; } ?>
<?php $component = App\View\Components\News::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('news'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\News::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3d452745d4a5eb38b6bef38907945e76)): ?>
<?php $attributes = $__attributesOriginal3d452745d4a5eb38b6bef38907945e76; ?>
<?php unset($__attributesOriginal3d452745d4a5eb38b6bef38907945e76); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3d452745d4a5eb38b6bef38907945e76)): ?>
<?php $component = $__componentOriginal3d452745d4a5eb38b6bef38907945e76; ?>
<?php unset($__componentOriginal3d452745d4a5eb38b6bef38907945e76); ?>
<?php endif; ?>
    
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\app1\resources\views/welcome.blade.php ENDPATH**/ ?>