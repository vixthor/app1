<img  class="w-full h-full " src="<?php echo e(asset('images/home/app_logo.svg')); ?>" alt="">
<?php /**PATH C:\xampp\htdocs\app1\resources\views\components\application-logo.blade.php ENDPATH**/ ?>