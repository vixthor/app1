<div class="flex flex-col gap-y-10 p-5 mt-20">
            <div class=" flex flex-col mx-auto items-center   gap-y-5">
                <?php if (isset($component)) { $__componentOriginale42c205f32cbec3ded5d4ffcf1218796 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale42c205f32cbec3ded5d4ffcf1218796 = $attributes; } ?>
<?php $component = App\View\Components\H3::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('h3'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\H3::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'font-bold text-6xl']); ?>Social Responsibility <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale42c205f32cbec3ded5d4ffcf1218796)): ?>
<?php $attributes = $__attributesOriginale42c205f32cbec3ded5d4ffcf1218796; ?>
<?php unset($__attributesOriginale42c205f32cbec3ded5d4ffcf1218796); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale42c205f32cbec3ded5d4ffcf1218796)): ?>
<?php $component = $__componentOriginale42c205f32cbec3ded5d4ffcf1218796; ?>
<?php unset($__componentOriginale42c205f32cbec3ded5d4ffcf1218796); ?>
<?php endif; ?>
                <img class="w-20" src="<?php echo e(asset('images/home/line_8.svg')); ?>" alt="erer">
                 <?php if (isset($component)) { $__componentOriginal9bea1a1944ba8334e0e356b0357f4b9d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9bea1a1944ba8334e0e356b0357f4b9d = $attributes; } ?>
<?php $component = App\View\Components\P::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('p'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\P::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'fony-thin text-center']); ?>At Madu Alliance, we believe in being a responsible corporate citizen. Our social responsibility initiatives focus on supporting the communities where we operate, fostering education, promoting diversity and inclusion, and ensuring the highest standards of safety and ethics in our operations. <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9bea1a1944ba8334e0e356b0357f4b9d)): ?>
<?php $attributes = $__attributesOriginal9bea1a1944ba8334e0e356b0357f4b9d; ?>
<?php unset($__attributesOriginal9bea1a1944ba8334e0e356b0357f4b9d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9bea1a1944ba8334e0e356b0357f4b9d)): ?>
<?php $component = $__componentOriginal9bea1a1944ba8334e0e356b0357f4b9d; ?>
<?php unset($__componentOriginal9bea1a1944ba8334e0e356b0357f4b9d); ?>
<?php endif; ?>
            </div>
            <div>
                <div class="hidden max-w-screen-2xl lg:flex mx-auto justify-around items-center py-14 gap-x-5">
                    <?php if (isset($component)) { $__componentOriginale67687e3e4e61f963b25a6bcf3983629 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale67687e3e4e61f963b25a6bcf3983629 = $attributes; } ?>
<?php $component = App\View\Components\Button::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Button::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>Community Development <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale67687e3e4e61f963b25a6bcf3983629)): ?>
<?php $attributes = $__attributesOriginale67687e3e4e61f963b25a6bcf3983629; ?>
<?php unset($__attributesOriginale67687e3e4e61f963b25a6bcf3983629); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale67687e3e4e61f963b25a6bcf3983629)): ?>
<?php $component = $__componentOriginale67687e3e4e61f963b25a6bcf3983629; ?>
<?php unset($__componentOriginale67687e3e4e61f963b25a6bcf3983629); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginale67687e3e4e61f963b25a6bcf3983629 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale67687e3e4e61f963b25a6bcf3983629 = $attributes; } ?>
<?php $component = App\View\Components\Button::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Button::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>Digital Transformation in Oil and Gas <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale67687e3e4e61f963b25a6bcf3983629)): ?>
<?php $attributes = $__attributesOriginale67687e3e4e61f963b25a6bcf3983629; ?>
<?php unset($__attributesOriginale67687e3e4e61f963b25a6bcf3983629); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale67687e3e4e61f963b25a6bcf3983629)): ?>
<?php $component = $__componentOriginale67687e3e4e61f963b25a6bcf3983629; ?>
<?php unset($__componentOriginale67687e3e4e61f963b25a6bcf3983629); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginale67687e3e4e61f963b25a6bcf3983629 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale67687e3e4e61f963b25a6bcf3983629 = $attributes; } ?>
<?php $component = App\View\Components\Button::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Button::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>Smart Refining and Processing <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale67687e3e4e61f963b25a6bcf3983629)): ?>
<?php $attributes = $__attributesOriginale67687e3e4e61f963b25a6bcf3983629; ?>
<?php unset($__attributesOriginale67687e3e4e61f963b25a6bcf3983629); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale67687e3e4e61f963b25a6bcf3983629)): ?>
<?php $component = $__componentOriginale67687e3e4e61f963b25a6bcf3983629; ?>
<?php unset($__componentOriginale67687e3e4e61f963b25a6bcf3983629); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginale67687e3e4e61f963b25a6bcf3983629 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale67687e3e4e61f963b25a6bcf3983629 = $attributes; } ?>
<?php $component = App\View\Components\Button::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Button::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>Renewable Energy and Low-Carbon Technologies <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale67687e3e4e61f963b25a6bcf3983629)): ?>
<?php $attributes = $__attributesOriginale67687e3e4e61f963b25a6bcf3983629; ?>
<?php unset($__attributesOriginale67687e3e4e61f963b25a6bcf3983629); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale67687e3e4e61f963b25a6bcf3983629)): ?>
<?php $component = $__componentOriginale67687e3e4e61f963b25a6bcf3983629; ?>
<?php unset($__componentOriginale67687e3e4e61f963b25a6bcf3983629); ?>
<?php endif; ?>
                </div>
                <div class="flex flex-col max-w-7xl lg:flex-row gap-x-20 mx-auto">
                    <div class=" h-full w-full">
                        <img  class="w-full h-full " src="<?php echo e(asset('images/home/social.svg')); ?>" alt="">
                    </div>
                    <div class="flex flex-col   w-full justify-center ">
                        <?php if (isset($component)) { $__componentOriginal9bea1a1944ba8334e0e356b0357f4b9d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9bea1a1944ba8334e0e356b0357f4b9d = $attributes; } ?>
<?php $component = App\View\Components\P::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('p'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\P::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'text-start font-bold px-2 py-3']); ?>Key Focus Areas <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9bea1a1944ba8334e0e356b0357f4b9d)): ?>
<?php $attributes = $__attributesOriginal9bea1a1944ba8334e0e356b0357f4b9d; ?>
<?php unset($__attributesOriginal9bea1a1944ba8334e0e356b0357f4b9d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9bea1a1944ba8334e0e356b0357f4b9d)): ?>
<?php $component = $__componentOriginal9bea1a1944ba8334e0e356b0357f4b9d; ?>
<?php unset($__componentOriginal9bea1a1944ba8334e0e356b0357f4b9d); ?>
<?php endif; ?>
                        <ul class="py-6 px-2">
                            <li class="py-5 gap-x-3 flex items-center"> 
                                   <img  class=" " src="<?php echo e(asset('images/home/list_icon.svg')); ?>" alt="">    
                                Supporting local infrastructure projects.
                            </li>
                            <li class="py-5 gap-x-3 flex items-center"> 
                                   <img  class=" " src="<?php echo e(asset('images/home/list_icon.svg')); ?>" alt="">    
                               Disaster relief and emergency response programs.
                            </li>
                             <li class="py-5 gap-x-3 flex items-center"> 
                                   <img  class=" " src="<?php echo e(asset('images/home/list_icon.svg')); ?>" alt="">    
                               Educational Advancement Initiatives.
                            </li>
                             <li class="py-5 gap-x-3 flex items-center"> 
                                   <img  class=" " src="<?php echo e(asset('images/home/list_icon.svg')); ?>" alt="">    
                              Health and Wellness Programs.
                            </li>
                             <li class="py-5 gap-x-3 flex items-center"> 
                                   <img  class=" " src="<?php echo e(asset('images/home/list_icon.svg')); ?>" alt="">    
                               Environmental Awareness Campaigns.
                            </li>
                             
                            
                        </ul>
                        <a class="underline text-button-blue gap-x-2 flex items-self-start" href="">Get Started <img src="<?php echo e(asset('images/home/direct_right.svg')); ?>" alt=""></a>
                    </div>
                </div>
            </div>

           

        </div>
    <!-- People find pleasure in different ways. I find it in keeping my mind clear. - Marcus Aurelius -->
</div><?php /**PATH C:\xampp\htdocs\app1\resources\views\components\social.blade.php ENDPATH**/ ?>