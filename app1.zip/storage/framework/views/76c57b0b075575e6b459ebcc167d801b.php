<div class="w-full" data-aos="fade-up">
     <div class=" flex flex-col mt-20 w-full mx-auto items-center max-w-7xl gap-y-5">
                    <?php if (isset($component)) { $__componentOriginale42c205f32cbec3ded5d4ffcf1218796 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale42c205f32cbec3ded5d4ffcf1218796 = $attributes; } ?>
<?php $component = App\View\Components\H3::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('h3'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\H3::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'font-bold  text-6xl']); ?>Environmental Initiatives <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale42c205f32cbec3ded5d4ffcf1218796)): ?>
<?php $attributes = $__attributesOriginale42c205f32cbec3ded5d4ffcf1218796; ?>
<?php unset($__attributesOriginale42c205f32cbec3ded5d4ffcf1218796); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale42c205f32cbec3ded5d4ffcf1218796)): ?>
<?php $component = $__componentOriginale42c205f32cbec3ded5d4ffcf1218796; ?>
<?php unset($__componentOriginale42c205f32cbec3ded5d4ffcf1218796); ?>
<?php endif; ?>
                    <img class="w-20" src="<?php echo e(asset('images/home/line_8.svg')); ?>" alt="erer">
        </div>
          <div class="flex p-4 flex-col lg:flex-row lg:p-5">
                    <div class="lg:w-1/3 w-full">
                        <img  class="w-full h-full " src="<?php echo e(asset('images/home/env1.svg')); ?>" alt="">
                    </div>
                    <div class="flex flex-col lg:w-2/3 w-full justify-center ">
                        <?php if (isset($component)) { $__componentOriginal9bea1a1944ba8334e0e356b0357f4b9d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9bea1a1944ba8334e0e356b0357f4b9d = $attributes; } ?>
<?php $component = App\View\Components\P::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('p'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\P::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'text-start text-base font-bold px-2 py-3']); ?>At Madu Alliance, we recognize our responsibility to the environment and are committed to sustainable practices. Our environmental initiatives focus on reducing our carbon footprint, protecting ecosystems, and investing in renewable energy. <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9bea1a1944ba8334e0e356b0357f4b9d)): ?>
<?php $attributes = $__attributesOriginal9bea1a1944ba8334e0e356b0357f4b9d; ?>
<?php unset($__attributesOriginal9bea1a1944ba8334e0e356b0357f4b9d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9bea1a1944ba8334e0e356b0357f4b9d)): ?>
<?php $component = $__componentOriginal9bea1a1944ba8334e0e356b0357f4b9d; ?>
<?php unset($__componentOriginal9bea1a1944ba8334e0e356b0357f4b9d); ?>
<?php endif; ?>
                        <ul class="py-8 px-2">
                            <li class="py-2  flex flex-col items-center"> 
                                <?php if (isset($component)) { $__componentOriginal1ad868a1e21b91c2e439a4442920aef3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1ad868a1e21b91c2e439a4442920aef3 = $attributes; } ?>
<?php $component = App\View\Components\DropdownCard::resolve(['title' => 'Carbon Footprint Reduction','description' => 'By adopting energy-efficient technologies, carbon capture solutions, and cleaner fuel alternatives, we aim to minimize emissions and reduce our environmental impact.'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dropdown-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\DropdownCard::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1ad868a1e21b91c2e439a4442920aef3)): ?>
<?php $attributes = $__attributesOriginal1ad868a1e21b91c2e439a4442920aef3; ?>
<?php unset($__attributesOriginal1ad868a1e21b91c2e439a4442920aef3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1ad868a1e21b91c2e439a4442920aef3)): ?>
<?php $component = $__componentOriginal1ad868a1e21b91c2e439a4442920aef3; ?>
<?php unset($__componentOriginal1ad868a1e21b91c2e439a4442920aef3); ?>
<?php endif; ?>
                                <?php if (isset($component)) { $__componentOriginal1ad868a1e21b91c2e439a4442920aef3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1ad868a1e21b91c2e439a4442920aef3 = $attributes; } ?>
<?php $component = App\View\Components\DropdownCard::resolve(['title' => 'Ecosystem Protection','description' => 'We prioritize preserving natural habitats and biodiversity by conducting thorough environmental assessments, implementing advanced spill prevention systems, and collaborating with conservation partners to restore ecosystems.'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dropdown-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\DropdownCard::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1ad868a1e21b91c2e439a4442920aef3)): ?>
<?php $attributes = $__attributesOriginal1ad868a1e21b91c2e439a4442920aef3; ?>
<?php unset($__attributesOriginal1ad868a1e21b91c2e439a4442920aef3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1ad868a1e21b91c2e439a4442920aef3)): ?>
<?php $component = $__componentOriginal1ad868a1e21b91c2e439a4442920aef3; ?>
<?php unset($__componentOriginal1ad868a1e21b91c2e439a4442920aef3); ?>
<?php endif; ?>
                                 <?php if (isset($component)) { $__componentOriginal1ad868a1e21b91c2e439a4442920aef3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1ad868a1e21b91c2e439a4442920aef3 = $attributes; } ?>
<?php $component = App\View\Components\DropdownCard::resolve(['title' => 'Renewable Energy Investment','description' => 'As part of our transition to a sustainable energy mix, we invest in renewable energy sources like solar, wind, and geothermal, while funding research and innovation to drive the green energy revolution.'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dropdown-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\DropdownCard::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1ad868a1e21b91c2e439a4442920aef3)): ?>
<?php $attributes = $__attributesOriginal1ad868a1e21b91c2e439a4442920aef3; ?>
<?php unset($__attributesOriginal1ad868a1e21b91c2e439a4442920aef3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1ad868a1e21b91c2e439a4442920aef3)): ?>
<?php $component = $__componentOriginal1ad868a1e21b91c2e439a4442920aef3; ?>
<?php unset($__componentOriginal1ad868a1e21b91c2e439a4442920aef3); ?>
<?php endif; ?>
                                 <?php if (isset($component)) { $__componentOriginal1ad868a1e21b91c2e439a4442920aef3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1ad868a1e21b91c2e439a4442920aef3 = $attributes; } ?>
<?php $component = App\View\Components\DropdownCard::resolve(['title' => 'Water Management','description' => 'Madu Alliance is committed to responsible water use, recycling water in operations, preventing contamination, and exploring innovative methods to reduce water consumption across all processes.'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dropdown-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\DropdownCard::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1ad868a1e21b91c2e439a4442920aef3)): ?>
<?php $attributes = $__attributesOriginal1ad868a1e21b91c2e439a4442920aef3; ?>
<?php unset($__attributesOriginal1ad868a1e21b91c2e439a4442920aef3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1ad868a1e21b91c2e439a4442920aef3)): ?>
<?php $component = $__componentOriginal1ad868a1e21b91c2e439a4442920aef3; ?>
<?php unset($__componentOriginal1ad868a1e21b91c2e439a4442920aef3); ?>
<?php endif; ?>
                            </li>
                            34.203.11.237
                        </ul>
                        
                    </div>
         </div> 
</div>        

    <!-- Knowing is not enough; we must apply. Being willing is not enough; we must do. - Leonardo da Vinci -->
<?php /**PATH C:\xampp\htdocs\app1\resources\views/components/environment.blade.php ENDPATH**/ ?>