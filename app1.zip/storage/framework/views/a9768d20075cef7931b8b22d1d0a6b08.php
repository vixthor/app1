<div class="font-medium md:text-4xl text-2xl mb-4">
   <?php echo e($slot); ?> <!-- An unexamined life is not worth living. - Socrates -->
</div><?php /**PATH C:\xampp\htdocs\app1\resources\views\components\h2.blade.php ENDPATH**/ ?>