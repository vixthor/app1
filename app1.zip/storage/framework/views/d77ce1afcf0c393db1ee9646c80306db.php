
    <div class="bg-background-yellow overflow-x-hidden  font-bold text-white w-full text-left lg:py-32 py-20  px-7 mb-24">
                    <p class="lg:text-6xl  text-lg md:text-4xl leading-snug">With a presence in over 20 countries we <br> are a significant industry leader in the oil <br> industry space. Join us in making Africa <br>
                    an oil giant in charge of it’s own <br> resources.</p>     
    </div> 
    <!-- When there is no desire, all things are at peace. - Laozi -->
<?php /**PATH C:\xampp\htdocs\app1\resources\views/components/backdrop.blade.php ENDPATH**/ ?>