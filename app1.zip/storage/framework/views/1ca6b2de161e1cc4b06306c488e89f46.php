<div class="text-center  font-bold lg:text-6xl text-3xl">
   <?php echo e($slot); ?> <!-- Order your soul. Reduce your wants. - Augustine -->
</div><?php /**PATH C:\xampp\htdocs\app1\resources\views\components\h3.blade.php ENDPATH**/ ?>