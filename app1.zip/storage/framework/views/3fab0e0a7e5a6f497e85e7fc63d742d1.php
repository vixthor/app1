<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        <div data-aos="fade-up" class="flex flex-col  md:flex-row container mx-auto py-20 px-5">
            <div class="w-full md:w-1/2">
                <?php if (isset($component)) { $__componentOriginal17d8a1166440eeccc4f83e2de75a36eb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal17d8a1166440eeccc4f83e2de75a36eb = $attributes; } ?>
<?php $component = App\View\Components\H2::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('h2'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\H2::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>How It Started <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal17d8a1166440eeccc4f83e2de75a36eb)): ?>
<?php $attributes = $__attributesOriginal17d8a1166440eeccc4f83e2de75a36eb; ?>
<?php unset($__attributesOriginal17d8a1166440eeccc4f83e2de75a36eb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal17d8a1166440eeccc4f83e2de75a36eb)): ?>
<?php $component = $__componentOriginal17d8a1166440eeccc4f83e2de75a36eb; ?>
<?php unset($__componentOriginal17d8a1166440eeccc4f83e2de75a36eb); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginal04a494435a2fe53fd374931f4f46901d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal04a494435a2fe53fd374931f4f46901d = $attributes; } ?>
<?php $component = App\View\Components\H1::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('h1'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\H1::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>The Journey So Far. <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal04a494435a2fe53fd374931f4f46901d)): ?>
<?php $attributes = $__attributesOriginal04a494435a2fe53fd374931f4f46901d; ?>
<?php unset($__attributesOriginal04a494435a2fe53fd374931f4f46901d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal04a494435a2fe53fd374931f4f46901d)): ?>
<?php $component = $__componentOriginal04a494435a2fe53fd374931f4f46901d; ?>
<?php unset($__componentOriginal04a494435a2fe53fd374931f4f46901d); ?>
<?php endif; ?>
                <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Sequi distinctio dolor, ea voluptatibus aliquid soluta alias recusandae dolorum. Facere dolore aut soluta magnam fugit blanditiis doloremque quas praesentium ullam maiores?</p>
            </div>
             <div class="w-full md:w-1/2">
                <img class="w-full h-1/2" src="<?php echo e(asset('images/home/carousel2.svg')); ?>" alt="">
                <div class=" items-center grid grid-cols-2">
                    <div class=" font-semibold text-5xl  flex  flex-col gap-y-3 p-10 ">
                         <h3><span class="countup" data-end-value="3.5">0</span></h3>
                        <p class="text-lg">Years Experience</p>
                    </div>
                    <div class=" font-semibold text-5xl  flex  flex-col gap-y-3 p-10 ">
                         <h3><span class="countup" data-end-value="3.5">0</span></h3>
                        <p class="text-lg">Years Experience</p>
                    </div>
                    <div class=" font-semibold text-5xl  flex  flex-col gap-y-3 p-10 ">
                         <h3><span class="countup" data-end-value="3.5">0</span></h3>
                        <p class="text-lg">Years Experience</p>
                    </div>
                    <div class=" font-semibold text-5xl  flex  flex-col gap-y-3 p-10 ">
                         <h3><span class="countup" data-end-value="3.5">0</span></h3>
                        <p class="text-lg">Years Experience</p>
                    </div>
                    
                </div>
            </div>
            
        </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\app1\resources\views\pages\about.blade.php ENDPATH**/ ?>