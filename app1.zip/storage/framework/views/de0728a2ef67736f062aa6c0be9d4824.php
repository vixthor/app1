<div class="dark:text-white dark:bg-gray-900">
    <div  class=" w-full flex flex-col overflow-x-hidden  mx-auto  p-6 ">
           
                        <div data-aos="zoom-in" class="mx-auto max-w-7xl my-10 flex flex-col items-center gap-y-9 text-center">
                            <?php if (isset($component)) { $__componentOriginal04a494435a2fe53fd374931f4f46901d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal04a494435a2fe53fd374931f4f46901d = $attributes; } ?>
<?php $component = App\View\Components\H1::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('h1'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\H1::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['data-aos' => 'zoom-in']); ?>Empowering Nigeria's Energy Future  <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal04a494435a2fe53fd374931f4f46901d)): ?>
<?php $attributes = $__attributesOriginal04a494435a2fe53fd374931f4f46901d; ?>
<?php unset($__attributesOriginal04a494435a2fe53fd374931f4f46901d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal04a494435a2fe53fd374931f4f46901d)): ?>
<?php $component = $__componentOriginal04a494435a2fe53fd374931f4f46901d; ?>
<?php unset($__componentOriginal04a494435a2fe53fd374931f4f46901d); ?>
<?php endif; ?>
                           
                            <?php if (isset($component)) { $__componentOriginal17d8a1166440eeccc4f83e2de75a36eb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal17d8a1166440eeccc4f83e2de75a36eb = $attributes; } ?>
<?php $component = App\View\Components\H2::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('h2'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\H2::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'font-medium text-4xl mb-4']); ?>Driving Sustainable Growth and Innovation in the Oil & Gas Industry <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal17d8a1166440eeccc4f83e2de75a36eb)): ?>
<?php $attributes = $__attributesOriginal17d8a1166440eeccc4f83e2de75a36eb; ?>
<?php unset($__attributesOriginal17d8a1166440eeccc4f83e2de75a36eb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal17d8a1166440eeccc4f83e2de75a36eb)): ?>
<?php $component = $__componentOriginal17d8a1166440eeccc4f83e2de75a36eb; ?>
<?php unset($__componentOriginal17d8a1166440eeccc4f83e2de75a36eb); ?>
<?php endif; ?>
                            <?php if (isset($component)) { $__componentOriginal9bea1a1944ba8334e0e356b0357f4b9d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9bea1a1944ba8334e0e356b0357f4b9d = $attributes; } ?>
<?php $component = App\View\Components\P::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('p'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\P::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'font-normal text-center']); ?>As a leading force in Nigeria's oil and gas sector, we are committed to powering the nation's progress through responsible energy production, advanced technologies, and community-driven initiatives. Explore our operations, discover our latest projects, and join us on our journey to create a sustainable future for generations to come. <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9bea1a1944ba8334e0e356b0357f4b9d)): ?>
<?php $attributes = $__attributesOriginal9bea1a1944ba8334e0e356b0357f4b9d; ?>
<?php unset($__attributesOriginal9bea1a1944ba8334e0e356b0357f4b9d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9bea1a1944ba8334e0e356b0357f4b9d)): ?>
<?php $component = $__componentOriginal9bea1a1944ba8334e0e356b0357f4b9d; ?>
<?php unset($__componentOriginal9bea1a1944ba8334e0e356b0357f4b9d); ?>
<?php endif; ?>

                            <?php if (isset($component)) { $__componentOriginald411d1792bd6cc877d687758b753742c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald411d1792bd6cc877d687758b753742c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.primary-button','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('primary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> Learn More <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald411d1792bd6cc877d687758b753742c)): ?>
<?php $attributes = $__attributesOriginald411d1792bd6cc877d687758b753742c; ?>
<?php unset($__attributesOriginald411d1792bd6cc877d687758b753742c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald411d1792bd6cc877d687758b753742c)): ?>
<?php $component = $__componentOriginald411d1792bd6cc877d687758b753742c; ?>
<?php unset($__componentOriginald411d1792bd6cc877d687758b753742c); ?>
<?php endif; ?>
                            <div>
                                                            <p class="underline">Our commitment to sustainability</p>    

                            </div>
                        </div>
                    </div>
                    <div class=" ">
        <div class="slick-carousel   overflow-x-hidden px-3">
            <div class="p-1"><img src="<?php echo e(asset('images/home/carousel1.svg')); ?>" alt="Image 1"></div>
            <div class="p-1"><img src="<?php echo e(asset('images/home/carousel2.svg')); ?>" alt="Image 2"></div>
            <div class="p-1"><img src="<?php echo e(asset('images/home/image.svg')); ?>" alt="Image 3"></div>
            <div class="p-1"><img src="<?php echo e(asset('images/home/carousel1.svg')); ?>" alt="Image 3"></div>
            <div class="p-1"><img src="<?php echo e(asset('images/home/carousel1.svg')); ?>" alt="Image 3"></div>
            <div class="p-1"><img src="<?php echo e(asset('images/home/carousel1.svg')); ?>" alt="Image 3"></div>
        </div>
    </div>
    <!-- Always remember that you are absolutely unique. Just like everyone else. - Margaret Mead -->
</div><?php /**PATH C:\xampp\htdocs\app1\resources\views/components/header.blade.php ENDPATH**/ ?>