<div>
    <div data-aos="fade-up" class=" w-full flex flex-col mx-auto items-center max-w-7xl gap-y-5">
            <?php if (isset($component)) { $__componentOriginale42c205f32cbec3ded5d4ffcf1218796 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale42c205f32cbec3ded5d4ffcf1218796 = $attributes; } ?>
<?php $component = App\View\Components\H3::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('h3'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\H3::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'font-bold text-6xl']); ?>What We Offer <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale42c205f32cbec3ded5d4ffcf1218796)): ?>
<?php $attributes = $__attributesOriginale42c205f32cbec3ded5d4ffcf1218796; ?>
<?php unset($__attributesOriginale42c205f32cbec3ded5d4ffcf1218796); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale42c205f32cbec3ded5d4ffcf1218796)): ?>
<?php $component = $__componentOriginale42c205f32cbec3ded5d4ffcf1218796; ?>
<?php unset($__componentOriginale42c205f32cbec3ded5d4ffcf1218796); ?>
<?php endif; ?>
            <img class="w-20" src="<?php echo e(asset('images/home/line_8.svg')); ?>" alt="">
          
        </div>
        <div class=" mx-auto mb-48">
            <?php if (isset($component)) { $__componentOriginal8226856e4e6a8cc6e39abcb820107e84 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8226856e4e6a8cc6e39abcb820107e84 = $attributes; } ?>
<?php $component = App\View\Components\Offers::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('offers'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Offers::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                 <?php $__env->slot('title', null, []); ?> 
                    Monthly Meetups
                 <?php $__env->endSlot(); ?>
                Our cornerstone event, held on the last Friday of every month, featuring keynote speakers, <br> panel discussions, and ample networking opportunities.
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8226856e4e6a8cc6e39abcb820107e84)): ?>
<?php $attributes = $__attributesOriginal8226856e4e6a8cc6e39abcb820107e84; ?>
<?php unset($__attributesOriginal8226856e4e6a8cc6e39abcb820107e84); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8226856e4e6a8cc6e39abcb820107e84)): ?>
<?php $component = $__componentOriginal8226856e4e6a8cc6e39abcb820107e84; ?>
<?php unset($__componentOriginal8226856e4e6a8cc6e39abcb820107e84); ?>
<?php endif; ?>
             <?php if (isset($component)) { $__componentOriginal8226856e4e6a8cc6e39abcb820107e84 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8226856e4e6a8cc6e39abcb820107e84 = $attributes; } ?>
<?php $component = App\View\Components\Offers::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('offers'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Offers::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                 <?php $__env->slot('title', null, []); ?> 
                    Diverse Network
                 <?php $__env->endSlot(); ?>
                Connect with a wide range of professionals, from early-stage founders to seasoned <br>entrepreneurs, investors, and industry experts.
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8226856e4e6a8cc6e39abcb820107e84)): ?>
<?php $attributes = $__attributesOriginal8226856e4e6a8cc6e39abcb820107e84; ?>
<?php unset($__attributesOriginal8226856e4e6a8cc6e39abcb820107e84); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8226856e4e6a8cc6e39abcb820107e84)): ?>
<?php $component = $__componentOriginal8226856e4e6a8cc6e39abcb820107e84; ?>
<?php unset($__componentOriginal8226856e4e6a8cc6e39abcb820107e84); ?>
<?php endif; ?>
             <?php if (isset($component)) { $__componentOriginal8226856e4e6a8cc6e39abcb820107e84 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8226856e4e6a8cc6e39abcb820107e84 = $attributes; } ?>
<?php $component = App\View\Components\Offers::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('offers'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Offers::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                 <?php $__env->slot('title', null, []); ?> 
                    Knowledge Sharing
                 <?php $__env->endSlot(); ?>
                Connect with a wide range of professionals, from early-stage founders to seasoned <br>entrepreneurs, investors, and industry experts.
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8226856e4e6a8cc6e39abcb820107e84)): ?>
<?php $attributes = $__attributesOriginal8226856e4e6a8cc6e39abcb820107e84; ?>
<?php unset($__attributesOriginal8226856e4e6a8cc6e39abcb820107e84); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8226856e4e6a8cc6e39abcb820107e84)): ?>
<?php $component = $__componentOriginal8226856e4e6a8cc6e39abcb820107e84; ?>
<?php unset($__componentOriginal8226856e4e6a8cc6e39abcb820107e84); ?>
<?php endif; ?>
             <?php if (isset($component)) { $__componentOriginal8226856e4e6a8cc6e39abcb820107e84 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8226856e4e6a8cc6e39abcb820107e84 = $attributes; } ?>
<?php $component = App\View\Components\Offers::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('offers'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Offers::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                 <?php $__env->slot('title', null, []); ?> 
                    Collaboration <br>  Opportunities
                 <?php $__env->endSlot(); ?>
                Find potential co-founders, mentors, or partners for your next big venture.
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8226856e4e6a8cc6e39abcb820107e84)): ?>
<?php $attributes = $__attributesOriginal8226856e4e6a8cc6e39abcb820107e84; ?>
<?php unset($__attributesOriginal8226856e4e6a8cc6e39abcb820107e84); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8226856e4e6a8cc6e39abcb820107e84)): ?>
<?php $component = $__componentOriginal8226856e4e6a8cc6e39abcb820107e84; ?>
<?php unset($__componentOriginal8226856e4e6a8cc6e39abcb820107e84); ?>
<?php endif; ?>
             <?php if (isset($component)) { $__componentOriginal8226856e4e6a8cc6e39abcb820107e84 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8226856e4e6a8cc6e39abcb820107e84 = $attributes; } ?>
<?php $component = App\View\Components\Offers::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('offers'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Offers::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                 <?php $__env->slot('title', null, []); ?> 
                    Community Support
                 <?php $__env->endSlot(); ?>
                Be part of a supportive ecosystem that celebrates successes and provides guidance <br> through challenges.
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8226856e4e6a8cc6e39abcb820107e84)): ?>
<?php $attributes = $__attributesOriginal8226856e4e6a8cc6e39abcb820107e84; ?>
<?php unset($__attributesOriginal8226856e4e6a8cc6e39abcb820107e84); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8226856e4e6a8cc6e39abcb820107e84)): ?>
<?php $component = $__componentOriginal8226856e4e6a8cc6e39abcb820107e84; ?>
<?php unset($__componentOriginal8226856e4e6a8cc6e39abcb820107e84); ?>
<?php endif; ?>

        </div>
    <!-- I have not failed. I've just found 10,000 ways that won't work. - Thomas Edison -->
</div><?php /**PATH C:\xampp\htdocs\app1\resources\views/components/whatweoffer.blade.php ENDPATH**/ ?>