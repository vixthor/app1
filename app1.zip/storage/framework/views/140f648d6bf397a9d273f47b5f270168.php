<button <?php echo e($attributes->merge(['class' => 'bg-yellow-500 text-white font-semibold px-4 py-2 rounded transition duration-300 hover:bg-yellow-600'])); ?>>
    <?php echo e($slot); ?>

</button><?php /**PATH C:\xampp\htdocs\app1\resources\views\components\primary-button.blade.php ENDPATH**/ ?>