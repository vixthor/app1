<div data-aos="fade-up" class="w-full mt-20">
    <div>    <!-- I have not failed. I've just found 10,000 ways that won't work. - Thomas Edison -->
    <div class=" flex flex-col mx-auto items-center max-w-7xl gap-y-5">
                <?php if (isset($component)) { $__componentOriginale42c205f32cbec3ded5d4ffcf1218796 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale42c205f32cbec3ded5d4ffcf1218796 = $attributes; } ?>
<?php $component = App\View\Components\H3::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('h3'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\H3::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'font-bold text-6xl']); ?>News and Media <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale42c205f32cbec3ded5d4ffcf1218796)): ?>
<?php $attributes = $__attributesOriginale42c205f32cbec3ded5d4ffcf1218796; ?>
<?php unset($__attributesOriginale42c205f32cbec3ded5d4ffcf1218796); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale42c205f32cbec3ded5d4ffcf1218796)): ?>
<?php $component = $__componentOriginale42c205f32cbec3ded5d4ffcf1218796; ?>
<?php unset($__componentOriginale42c205f32cbec3ded5d4ffcf1218796); ?>
<?php endif; ?>
                <img src="<?php echo e(asset('images/home/line_8.svg')); ?>" alt="erer">
                 <?php if (isset($component)) { $__componentOriginal9bea1a1944ba8334e0e356b0357f4b9d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9bea1a1944ba8334e0e356b0357f4b9d = $attributes; } ?>
<?php $component = App\View\Components\P::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('p'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\P::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'fony-thin text-center p-4']); ?>Welcome to the News & Media section of Madu Aliiance. Stay updated with the latest news, press releases, and media coverage about our company, projects, and initiatives. This section provides real-time insights into our operational achievements, community engagements, technological advancements, and industry contributions. We are committed to keeping our stakeholders informed about our progress and milestones as we continue to shape the energy landscape. <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9bea1a1944ba8334e0e356b0357f4b9d)): ?>
<?php $attributes = $__attributesOriginal9bea1a1944ba8334e0e356b0357f4b9d; ?>
<?php unset($__attributesOriginal9bea1a1944ba8334e0e356b0357f4b9d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9bea1a1944ba8334e0e356b0357f4b9d)): ?>
<?php $component = $__componentOriginal9bea1a1944ba8334e0e356b0357f4b9d; ?>
<?php unset($__componentOriginal9bea1a1944ba8334e0e356b0357f4b9d); ?>
<?php endif; ?>

        

    </div>
    <div class="slick-carousel overflow-x-hidden py-20 mb-20  ">
                    <div class=" text-center p-2">
                        <img class="w-full h-full" src="<?php echo e(asset('images/home/news.svg')); ?>" alt="Image 3">
                        <div class="p-3">
                            <h2 class="text-base text-start font-semibold">Latest News</h2>
                            <p class="text-start">Explore breaking news stories and updates about Madu Alliance. From new projects and partnerships to achievements and sustainability initiatives, this section offers a glimpse into our ongoing efforts to drive growth and innovation in the energy industry.</p>
                        </div>
                    </div>
                    <div class=" text-center p-2">
                        <img class="w-full h-full" src="<?php echo e(asset('images/home/news2.svg')); ?>" alt="Image 3">
                        <div class="p-3">
                            <h2 class="text-base text-start font-semibold">Latest News</h2>
                            <p class="text-start">Explore breaking news stories and updates about Madu Alliance. From new projects and partnerships to achievements and sustainability initiatives, this section offers a glimpse into our ongoing efforts to drive growth and innovation in the energy industry.</p>
                        </div>
                    </div>
                    <div class=" text-center p-2">
                        <img class="w-full h-full" src="<?php echo e(asset('images/home/news3.svg')); ?>" alt="Image 3">
                        <div class="p-3">
                            <h2 class="text-base text-start font-semibold">Latest News</h2>
                            <p class="text-start">Explore breaking news stories and updates about Madu Alliance. From new projects and partnerships to achievements and sustainability initiatives, this section offers a glimpse into our ongoing efforts to drive growth and innovation in the energy industry.</p>
                        </div>
                    </div><div class=" text-center p-2">
                        <img class="w-full h-full" src="<?php echo e(asset('images/home/news4.svg')); ?>" alt="Image 3">
                        <div class="p-3">
                            <h2 class="text-base text-start font-semibold">Latest News</h2>
                            <p class="text-start">Explore breaking news stories and updates about Madu Alliance. From new projects and partnerships to achievements and sustainability initiatives, this section offers a glimpse into our ongoing efforts to drive growth and innovation in the energy industry.</p>
                        </div>
                    </div>
                    
                      
    </div>
    <!-- Breathing in, I calm body and mind. Breathing out, I smile. - Thich Nhat Hanh -->
</div><?php /**PATH C:\xampp\htdocs\app1\resources\views/components/news.blade.php ENDPATH**/ ?>