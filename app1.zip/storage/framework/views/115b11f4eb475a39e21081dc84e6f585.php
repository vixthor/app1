<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<div class="mt-6 p-3">
    <?php if(session('success')): ?>
        <div class="mb-4 text-green-600">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <?php if (isset($component)) { $__componentOriginalb2ce5c1c6ebc7a5e222ea1aea2aa6207 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb2ce5c1c6ebc7a5e222ea1aea2aa6207 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.contact-form','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('contact-form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb2ce5c1c6ebc7a5e222ea1aea2aa6207)): ?>
<?php $attributes = $__attributesOriginalb2ce5c1c6ebc7a5e222ea1aea2aa6207; ?>
<?php unset($__attributesOriginalb2ce5c1c6ebc7a5e222ea1aea2aa6207); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb2ce5c1c6ebc7a5e222ea1aea2aa6207)): ?>
<?php $component = $__componentOriginalb2ce5c1c6ebc7a5e222ea1aea2aa6207; ?>
<?php unset($__componentOriginalb2ce5c1c6ebc7a5e222ea1aea2aa6207); ?>
<?php endif; ?>
</div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\app1\resources\views/pages/contact.blade.php ENDPATH**/ ?>