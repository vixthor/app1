<x-app-layout>
 




<button @click="toggleTheme()" class="px-4 py-2 m-2 bg-gray-300 dark:bg-gray-700 text-black dark:text-white rounded flex items-center">
    <svg x-show="!darkMode" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" class="h-5 w-5 mr-2">
        <path stroke-linecap="round" stroke-linejoin="round" d="M12 3v2m0 14v2m9-9h-2m-14 0H3m16.364-7.364l-1.414 1.414M7.05 16.95l-1.414 1.414m12.728 0l1.414-1.414M7.05 7.05l1.414-1.414" />
    </svg>
    <svg x-show="darkMode" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" class="h-5 w-5 mr-2">
        <path stroke-linecap="round" stroke-linejoin="round" d="M12 3v2m0 14v2m9-9h-2m-14 0H3m16.364-7.364l-1.414 1.414M7.05 16.95l-1.414 1.414m12.728 0l1.414-1.414M7.05 7.05l1.414-1.414" />
    </svg>
    
</button>
   
    <x-header></x-header>
    <x-whatwedo></x-whatwedo>
    <!-- good --> <x-backdrop></x-backdrop>
    <!-- good --> <x-whatweoffer></x-whatweoffer>
    <!-- good --> <x-whoweare></x-whoweare>
    <!-- good --> <x-technology></x-technology>
    <!-- good --> <x-environment></x-environment>
    <!-- good --> <x-social></x-social>
    <!-- good --> <x-leaders></x-leaders>
    <!-- good --> <x-relations></x-relations>
    <x-news></x-news>
    
</x-app-layout>
