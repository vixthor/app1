<div class="font-bold text-5xl">
    {{ $slot }}<!-- It is quality rather than quantity that matters. - Lucius Annaeus Seneca -->
</div>