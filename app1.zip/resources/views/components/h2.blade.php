<div class="font-medium md:text-4xl text-2xl mb-4">
   {{ $slot }} <!-- An unexamined life is not worth living. - Socrates -->
</div>