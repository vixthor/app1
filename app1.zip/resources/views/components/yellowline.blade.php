<div data-aos="fade-up"  class=" flex flex-col mx-auto items-center w-full max-w-7xl gap-y-1 lg:gap-y-">
                <x-h3 class="font-bold text-6xl">{{ $slot }}</x-h3>
                <img class="w-20 md:-w-20" src="{{ asset('images/home/line_8.svg') }}" alt="erer">
</div>