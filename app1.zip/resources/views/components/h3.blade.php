<div class="text-center  font-bold lg:text-6xl text-3xl">
   {{ $slot }} <!-- Order your soul. Reduce your wants. - Augustine -->
</div>