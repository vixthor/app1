<img  class="w-full h-full " src="{{ asset('images/home/app_logo.svg') }}" alt="">
